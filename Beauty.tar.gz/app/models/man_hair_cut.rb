# frozen_string_literal: true

class ManHairCut < ApplicationRecord
  def man_hair
    ManHairCut.all
  end
end

# frozen_string_literal: true

class WomenHairCut < ApplicationRecord
  def women_hair
    WomenHairCut.all
  end
end

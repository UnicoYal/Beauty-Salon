# frozen_string_literal: true

require 'test_helper'

class DepilationTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

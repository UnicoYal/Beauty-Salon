# frozen_string_literal: true

require 'test_helper'

class ManicureTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end

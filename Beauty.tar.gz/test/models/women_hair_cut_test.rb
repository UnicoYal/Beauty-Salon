# frozen_string_literal: true

require 'test_helper'

class WomenHairCutTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
